"""Read-only structural checks for the five-file ranking dataset."""
import hashlib
import json
from pathlib import Path


def check_dataset(folder):
    folder = Path(folder)
    summary = json.loads((folder / 'summary.json').read_text(encoding='utf-8'))
    manifest = json.loads((folder / 'manifest.json').read_text(encoding='utf-8'))
    datasets = {s: json.loads((folder / f'{s}.json').read_text(encoding='utf-8'))
                for s in ('train', 'validation', 'test')}
    results = []

    def add(name, steps, expected, ok, actual):
        results.append(dict(name=name, steps=steps, expected=expected,
                            status='PASS' if ok else 'FAIL', actual=actual))

    for split, data in datasets.items():
        queries = data['queries']
        count = len(queries)
        wanted = summary['counts'][split]
        add(f'{split.title()} example count', f'Count queries in {split}.json; compare summary.json.',
            f'{wanted:,} queries, matching summary.json.', count == wanted, f'{count:,} queries; summary declares {wanted:,}.')
        lengths = sorted({len(q['items']) for q in queries})
        add(f'{split.title()} candidate count', f'Inspect every query in {split}.json.',
            '15 candidates per query.', lengths == [15], f'Observed candidate counts: {lengths}.')
        bad = sum(i['place_id'] not in data['places'] for q in queries for i in q['items'])
        add(f'{split.title()} place references', f'Resolve every item place_id against the {split} place dictionary.',
            'Zero missing place references.', bad == 0, f'{bad} missing references.')
        bad = sum(not(type(i['relevance']) is int and 0 <= i['relevance'] <= 4) for q in queries for i in q['items'])
        add(f'{split.title()} relevance grades', f'Inspect the type and range of every relevance grade in {split}.json.',
            'All grades are integers from 0 to 4.', bad == 0, f'{bad} invalid grades.')
        exists = 'price_ratio' in data['feature_names']
        add(f'{split.title()} feature declaration', f'Inspect feature_names in {split}.json.',
            'price_ratio is declared.', exists, f'price_ratio present: {exists}.')
    for first in ('train', 'validation'):
        count = len(set(datasets[first]['places']) & set(datasets['test']['places']))
        add(f'{first.title()}/test place separation', f'Intersect stored place IDs in {first}.json and test.json.',
            'Zero shared place IDs.', count == 0, f'{count} shared place IDs.')
    profiles = lambda s: {json.dumps(q['profile'], sort_keys=True) for q in datasets[s]['queries']}
    count = len(profiles('train') & profiles('validation'))
    add('Training/validation profile separation', 'Serialize profiles with sorted keys; intersect train/validation sets.',
        'Zero identical profiles across train and validation.', count == 0, f'{count} identical profiles across splits.')
    digest = hashlib.sha256(json.dumps(manifest, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()
    ok = digest == summary['manifest_sha256']
    add('Manifest integrity', 'Hash canonical manifest JSON using the preparation code serialization; compare summary digest.',
        'Calculated SHA-256 equals summary.json manifest_sha256.', ok, f'Digest matches: {ok}; {digest}.')
    return results


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('dataset')
    args = parser.parse_args()
    results = check_dataset(args.dataset)
    print(json.dumps(results, indent=2))
    raise SystemExit(any(r['status'] != 'PASS' for r in results))
