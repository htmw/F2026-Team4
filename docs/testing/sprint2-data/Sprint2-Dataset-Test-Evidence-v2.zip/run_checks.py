"""Repeat the preparation tests, dataset checks and coverage measurements."""
import argparse
import json
import subprocess
import sys
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--repo', required=True, type=Path)
parser.add_argument('--dataset', required=True, type=Path)
parser.add_argument('--output', default='data-evidence-results', type=Path)
args = parser.parse_args()
repo, dataset, output = args.repo.resolve(), args.dataset.resolve(), args.output.resolve()
checker = Path(__file__).with_name('check_dataset.py').resolve()
if output.exists():
    parser.error('Output folder already exists. Choose a new --output folder.')
modules = ['test_dataset_io', 'test_preparation_integration', 'test_prepare_dataset',
           'test_prepare_live', 'test_prepare_manifest']
for name in modules:
    if not (repo / 'ranker/tests' / (name + '.py')).is_file():
        parser.error('Preparation test files are missing from --repo.')
for name in ['train', 'validation', 'test', 'manifest', 'summary']:
    if not (dataset / (name + '.json')).is_file():
        parser.error('Missing dataset file: ' + name + '.json')
output.mkdir(parents=True)


def call(command, log=None):
    result = subprocess.run(command, cwd=repo, capture_output=True, text=True)
    text = result.stdout + result.stderr
    if log:
        log.write_text(text, encoding='utf-8')
    if result.returncode:
        print(text)
        raise SystemExit(result.returncode)
    return result.stdout


def config(name, scope):
    path = output / (name + '.ini')
    content = ('[run]\nparallel = true\npatch = subprocess\n'
               'data_file = ' + (output / ('.coverage-' + name)).as_posix() + '\n' + scope +
               '\n[report]\nprecision = 1\nshow_missing = true\n')
    path.write_text(content, encoding='utf-8')
    return path


def coverage(action, cfg, *rest, log=None):
    return call([sys.executable, '-m', 'coverage', action, '--rcfile=' + str(cfg), *rest], log)


scope = ('include =\n    */ranker/dataset_io.py\n    */ranker/prepare_dataset.py\n'
         '    */ranker/prepare_live.py\n    */ranker/prepare_manifest.py\n'
         '    ' + checker.as_posix() + '\n')
cfg = config('preparation', scope)
coverage('run', cfg, '-m', 'pytest',
         *['ranker/tests/' + n + '.py' for n in modules], '-v',
         '--junitxml=' + str(output / 'pytest-results.xml'),
         log=output / 'pytest-output.txt')
dataset_output = coverage('run', cfg, str(checker), str(dataset))
json.loads(dataset_output)
(output / 'full-dataset-results.json').write_text(dataset_output, encoding='utf-8')
coverage('combine', cfg)
coverage('json', cfg, '-o', str(output / 'coverage.json'))
print(coverage('report', cfg))

scope = 'source = ranker.dataset_io,ranker.train,ranker.evaluate,ranker.features\n'
for label, test in [
    ('model-compatibility', 'ranker/tests/test_preparation_integration.py::test_loaded_sample_is_accepted_by_model_functions'),
    ('sample-integration', 'ranker/tests/test_preparation_integration.py'),
]:
    cfg = config(label, scope)
    coverage('run', cfg, '-m', 'pytest', test, '-q', log=output / (label + '-test-output.txt'))
    coverage('combine', cfg)
    coverage('json', cfg, '-o', str(output / (label + '.json')))
    print(label + '\n' + coverage('report', cfg))

print('Results saved to ' + str(output))
