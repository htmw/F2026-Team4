# Sprint 2 - Dataset test evidence

Run: 15 November 2026, Windows / Python 3.11.17.

- 60 automated tests passed.
- 19 full-dataset checks passed.
- Preparation and dataset-checker statement coverage: 88.1%.
- Sample integration and model compatibility statement coverage: 70.2% each.

The PDF groups selected checks into 18 test cases. These overlap the automated tests and are not an additional 18 tests.

## Files

- pytest-output.txt: automated test output.
- full-dataset-results.json: checks of the full training, validation and testing files.
- coverage.json: preparation and dataset-checker coverage.
- model-compatibility.json and sample-integration.json: coverage for the separate sample runs.
- model-compatibility-test-output.txt and sample-integration-test-output.txt: results of those runs.
- run_checks.py and check_dataset.py: scripts used to run the checks.

## Run again

From the project root, after running `uv sync --frozen`:

```powershell
uv run --with coverage==7.17.3 python "C:\Users\pravi\Downloads\Sprint2-Dataset-Test-Evidence\run_checks.py" --repo . --dataset data/ranking_dataset_v3 --output data-evidence-results-new
```

Use the path where you extracted this package. The output folder must not already exist.
